﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace STEP3_2_Call
{
    public partial class WorldQuiz : Form
    {
        //Dllファイルのインポート
        [DllImport("STEP3-2_DLL.dll")]
        static extern void Call_English();
        [DllImport("STEP3-2_DLL.dll")]
        static extern void Call_Korean();
        [DllImport("STEP3-2_DLL.dll")]
        static extern void Call_Arabic();
        [DllImport("STEP3-2_DLL.dll")]
        static extern void Call_Gorilla();
        [DllImport("STEP3-2_DLL.dll")]
        static extern void Call_IWAKAWA();

        public WorldQuiz()
        {
            InitializeComponent();
        }
        /// <summary>
        /// 問題1が押下された時に、メッセージボックスでこんにちは(英語)を表示
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void quizEnglish_Click(object sender, EventArgs e)
        {
            string EnglishPath = @"..\..\アメリカ人.jpg";
            //メソッドの呼び出し
            Call_English();
            //画像ファイルを読み込んで、Imageオブジェクトを作成する
            System.Drawing.Image img = System.Drawing.Image.FromFile(EnglishPath);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            //画像を表示する
            pictureBox1.Image = img;
        }
        /// <summary>
        /// 問題2が押下された時に、メッセージボックスでこんにちは(韓国語)を表示
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void quizKorean_Click(object sender, EventArgs e)
        {
            string KoreanPath = @"..\..\韓国人.jpg";
            //メソッドの呼び出し
            Call_Korean();
            //画像ファイルを読み込んで、Imageオブジェクトを作成する
            System.Drawing.Image img = System.Drawing.Image.FromFile(KoreanPath);
            pictureBox2.SizeMode = PictureBoxSizeMode.StretchImage;
            //画像を表示する
            pictureBox2.Image = img;

        }
        /// <summary>
        /// 問題3が押下された時に、メッセージボックスでこんにちは(アラビア語)を表示
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void quizArabic_Click(object sender, EventArgs e)
        {
            string ArabicPath = @"..\..\アラビア人.jpeg";
            //メソッドの呼び出し
            Call_Arabic();
            //画像ファイルを読み込んで、Imageオブジェクトを作成する
            System.Drawing.Image img = System.Drawing.Image.FromFile(ArabicPath);
            pictureBox3.SizeMode = PictureBoxSizeMode.StretchImage;
            //画像を表示する
            pictureBox3.Image = img;
        }
        /// <summary>
        /// 問題4が押下された時に、メッセージボックスでこんにちは(ゴリラ)を表示
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void quizGorilla_Click(object sender, EventArgs e)
        {
            string GorillaPath = @"..\..\ゴリラ.jpg";
            //メソッドの呼び出し
            Call_Gorilla();
            //画像ファイルを読み込んで、Imageオブジェクトを作成する
            System.Drawing.Image img = System.Drawing.Image.FromFile(GorillaPath);
            pictureBox4.SizeMode = PictureBoxSizeMode.StretchImage;
            //画像を表示する
            pictureBox4.Image = img;
        }
        /// <summary>
        /// 問題1が押下された時に、メッセージボックスでこんにちは(岩川)を表示
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void quizIWAKAWA_Click(object sender, EventArgs e)
        {
            string IWAKAWAPath = @"..\..\岩川.jpeg";
            //メソッドの呼び出し
            Call_IWAKAWA();
            //画像ファイルを読み込んで、Imageオブジェクトを作成する
            System.Drawing.Image img = System.Drawing.Image.FromFile(IWAKAWAPath);
            pictureBox5.SizeMode = PictureBoxSizeMode.StretchImage;
            //画像を表示する
            pictureBox5.Image = img;
        }

    }
}
