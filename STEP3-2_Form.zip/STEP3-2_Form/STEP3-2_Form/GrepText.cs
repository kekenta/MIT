﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
namespace STEP3_2_Form
{
    public partial class GrepText : Form
    {
        [DllImport("STEP3-2_DLL.dll", CharSet = CharSet.Unicode)]
        extern static void Serch(string s,string st);

        public GrepText()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //ダイアログを表示
            DialogResult Dialog = folderBrowserDialog1.ShowDialog();
            if (Dialog == System.Windows.Forms.DialogResult.OK)
            {
                textBox1.Text = folderBrowserDialog1.SelectedPath;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //ダイアログを表示
            DialogResult Dialog = openFileDialog1.ShowDialog();
            if (Dialog == System.Windows.Forms.DialogResult.OK)
            {
                textBox2.Text = openFileDialog1.FileName;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //変数の宣言
            string directoryPath = $"{ textBox1.Text}\\*.*";
            string outputPath = textBox2.Text;
            Serch(directoryPath,outputPath);
        }
    }
}
