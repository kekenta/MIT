﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;

namespace HelloWorld_Call_Dll
{   /// <summary>
    ///C++で作成したDLLファイルを呼び出し、Hello Worldを表示するクラス 
    /// </summary>
    public partial class Call_Dll : Form
    {
        //Dllファイルのインポート
        [DllImport("HelloWorld_Dll.dll")]
        //Dllファイル内のメソッドを定義
        static extern void Call_HelloWorld();

        /// <summary>
        /// Call_Dllのコンストラクタ
        /// </summary>
        public Call_Dll()
        {
            InitializeComponent();
        }

        private void CallButtom(object sender, EventArgs e)
        {
            //メソッドの呼び出し
            Call_HelloWorld();

        }
    }
}
