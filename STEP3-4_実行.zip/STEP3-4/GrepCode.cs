﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;
namespace STEP3_4
{
    public partial class GrepCode : Form
    {
        [DllImport("STEP3-4_DLL.dll", CharSet = CharSet.Unicode)]
        extern static void Serch(string inputPath, string outputPath,string serchCode);

        public GrepCode()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //ダイアログを表示
            DialogResult Dialog = folderBrowserDialog1.ShowDialog();
            if (Dialog == System.Windows.Forms.DialogResult.OK)
            {
                textBox1.Text = folderBrowserDialog1.SelectedPath;
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            //ダイアログを表示
            DialogResult Dialog = openFileDialog1.ShowDialog();
            if (Dialog == System.Windows.Forms.DialogResult.OK)
            {
                //textBox2.Text = folderBrowserDialog2.SelectedPath;
                textBox2.Text = openFileDialog1.FileName;
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            //DLLに値を代入
            Serch(textBox1.Text,textBox2.Text,textBox3.Text);
        }
    }
}
